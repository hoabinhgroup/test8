window.SlotMachine = require('./slot-machine');
